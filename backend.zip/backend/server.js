import cors from 'cors';
import express from 'express';
import mysql from 'mysql2';
import jwt from 'jsonwebtoken';
import cookieParser from 'cookie-parser';
import db from './Config/serverConfig.js';
import authRoute from './Routes/categoryControllers.js';









// const express = require("express");
// const mysql2 = require("mysql2");
// const cors = require("cors");
// const cookieParser = require("cookie-parser");
// const jwt = require("jsonwebtoken");
//const nodemailer = require("nodemailer");
//const transporter = require("transporter");


// const db = mysql2.createConnection({
//     host: '192.168.30.75',
//     user: 'user',
//     password: 'pass',
//     database: 'ecart'   
// });

db.connect(err => {
    if (err) throw err;
    console.log("connected to the db");
});

const app = express();

app.use(cors());
app.use(express.json());
app.use(cookieParser());
app.use('/api/',authRoute);
//app.use(nodemailer());

// app.get('/', (req, res) => {
//     res.send("I am from the Backend");
// });

// app.get('/products', (req, res) => {
//     const q = "SELECT * FROM products";
//     if (req.cookies.deepthi)
//         {
//             jwt.verify(req.cookies.deepthi,'Deepthi',(err,result)=>{
//                 if (err) throw err
//                 db.query(q, (err, result) => {
//                     if (err) throw err;
            
//                     res.status(200).json(result);
//                     console.log(req.cookies.deepthi)
//                     //res.cookie ("deepthi", token,{httpOnly:true}).status(200).json("Login Successful")
                    
                    
//                 });

                
//             })
            
//         }
//         else{
//             res.status(200).json(" Not Authenticate User")
            

//         }

    
// });
// app.get('/logout',(req, res) => {
//     console.log(req.cookies.deepthi)
//     res.clearCookie('deepthi',{
//         secure:true,
//         Samesite:"none"
//     }).status(200).json("Logged out")

//     })
    


// // deepthi:''
// app.get('/deepthi', (req, res) => {
//     const q = `SELECT u.username, p.title, pi.quantity, pi.total_price 
//                FROM users u 
//                JOIN purchesed_items pi ON u.id = pi.userId 
//                JOIN products p ON pi.productId = p.id 
//                WHERE u.username = 'deepthi'`; 
//     db.query(q, (err, result) => {
//         if (err) throw err;
//         res.status(200).json(result);
//     });
// });

// // dibya:''
// app.get('/dibya', (req, res) => {
//     const q =`SELECT u.username, p.title, p.rating
//     FROM users u
//     JOIN purchesed_items pi ON u.id = pi.userId
//     JOIN products p ON pi.productId = p.id
//     where u.username = "deepthi" `; 
//     db.query(q, (err, result) => {
//         if (err) throw err;
//         res.status(200).json(result);
//     });
// });

// // Madhav:''

// app.get('/Madhav', (req, res) => {
//     const q =`SELECT u.username, p.title, COUNT(pi.itemId) AS item_count
//     FROM users u
//     JOIN purchesed_items pi ON u.id = pi.userId
//     JOIN products p ON pi.productId = p.id
//     WHERE u.username = "deepthi"
//     GROUP BY u.username, p.title`;
      
//     db.query(q, (err, result) => {
//         if (err) throw err;
//         res.status(200).json(result);
//     });
// });

// //Rajitha:''
// app.get('/Rajitha', (req, res) => {
//     const q = `SELECT u.username, SUM(pi.total_price) AS totalspend
//     FROM users u
//     JOIN purchesed_items pi ON u.id = pi.userId
//     GROUP BY u.username`;
//     db.query(q, (err, result) => {
//         if (err) throw err;
//         res.status(200).json(result);
//     });
// });

// //Shreya:''
// app.get('/Shreya', (req, res) => {
//     const q = `SELECT u.id, u.username, SUM(pi.total_price) AS amount
//     FROM users u
//     JOIN purchesed_items pi ON u.id = pi.userId
//     GROUP BY u.id, u.username`;
//     db.query(q, (err, result) => {
//         if (err) throw err;
//         res.status(200).json(result);
//     });
// });


// app.post('/login', (req, res) => {
//     const username = req.body.username;
//     const password = req.body.password;

//     const q = "SELECT * FROM users WHERE username = ? AND password = ?";
//     const values = [username, password];

//     db.query(q, values, (err, result) => {
//         if (err) {
//             throw err;
//         }

//         if (result.length === 0) {
//             res.status(200).json('Invalid user');
//         } else {
//             const token = jwt.sign({id:1}, 'Deepthi');
//             console.log(token)
//             res.cookie ("deepthi", token,{httpOnly:true}).status(200).json("Login Successful")

//         }
//     });
// });

// app.get('/jwt',(req,res) => {
//     const token = jwt.sign({id:1}, 'Deepthi');
//     console.log(token)
//     res.status(401).json('jwt token');
  
// });

// app.post('/verifyjwt',(req,res) => {
//     const token = req.body.token
//     console.log(req.body)
//     jwt.verify(token,'Deepthi',(err,result)=>{
//         if (err) throw err
//         res.status(400).json(result)

        

//     })
// });



// app.post('/verifyjwt', (req, res) => {
//   const token = req.body.token;
//   console.log(req.body);

//   jwt.verify(token, 'Deepthi', (err, result) => {
//     if (err) {
//       res.status(401).json('Invalid Token');
//     } else {
//       if (result) {
    
//         res.status(200).json('Login is Successful');
//       } else {
//         res.status(401).json('Invalid User');
//       }
//     }
//   });
// });



// const transporter = nodemailer.createTransport({
//     service: 'gmail', 
//     auth: {
//       user: 'deepthim@brightcomgroup.com',
//       pass: 'yskvpttkiwocskts',
//     },
//   });
  
//   app.post('/send-email', (req, res) => {

//     const mailOptions = {
//       from: 'deepthim@brightcomgroup.com',
//       to: 'madhavas@brightcomgroup.com',
//       subject: 'Hello from Node.js',
//       text: 'This is a test email sent from Node.js.',
//     };
  

//     transporter.sendMail(mailOptions, (error, info) => {
//       if (error) {
//         console.error('Error sending email:', error);
//         res.status(500).json({ error: 'Email sending failed' });
//       } else {
//         console.log('Email sent:', info.response);
//         res.status(200).json({ message: 'Email sent successfully' });
//       }
//     });
//   });






//deepthi:''
// app.post('/deepthi', (req, res) => {
//     const userId = req.body.userId; 
//     //console.log(userId)

//     const q = `SELECT u.username, p.title, pi.quantity, pi.total_price 
//     FROM users u 
//     JOIN purchesed_items pi ON u.id = pi.userId 
//     JOIN products p ON pi.productId = p.id 
//     WHERE u.id = '?'`;

//     db.query(q, [userId], (err, result) => {
//         if (err) {
//             console.error(err);
//             res.status(500).json('Server Error');
//             return;
//         }

        
//         if (result.length > 0) {
//             res.status(200).json(result);
//         } else {
//             res.status(404).json('No Purchases Found for User');
//         }
//     });
// });


// //Dibya:''

// app.post('/Dibya', (req, res) => {
//     const username = req.body.username; 

//     const q = `SELECT u.username, p.title, p.rating
//     FROM users u
//     JOIN purchesed_items pi ON u.id = pi.userId
//     JOIN products p ON pi.productId = p.id
//     where u.username = "deepthi" `;

//     db.query(q, [username], (err, result) => {
//         if (err) {
//             console.error(err);
//             res.status(500).json('Server Error');
//             return;
//         }

        
//         if (result.length > 0) {
//             res.status(200).json(result);
//         } else {
//             res.status(404).json('No Purchases Found for User');
//         }
//     });
// });


// //Madhav:''

// app.post('/Madhav', (req, res) => {
//     const userId = req.body.id; 

//     const q = `SELECT u.username, p.title, COUNT(pi.itemId) AS item_count
//     FROM users u
//     JOIN purchesed_items pi ON u.id = pi.userId
//     JOIN products p ON pi.productId = p.id
//     WHERE u.username = "deepthi"
//     GROUP BY u.username, p.title`; 

//     db.query(q, [userId], (err, result) => {
//         if (err) {
//             console.error(err);
//             res.status(500).json('Server Error');
//             return;
//         }

        
//         if (result.length > 0) {
//             res.status(200).json(result);
//         } else {
//             res.status(404).json('No Purchases Found for User');
//         }
//     });
// });


// //Rajitha
// app.post('/Rajitha', (req, res) => {
//     const userId = req.body.id; 

//     const q = `SELECT u.username, SUM(pi.total_price) AS totalspend
//     FROM users u
//     JOIN purchesed_items pi ON u.id = pi.userId
//     GROUP BY u.username`; 

//     db.query(q, [userId], (err, result) => {
//         if (err) {
//             console.error(err);
//             res.status(500).json('Server Error');
//             return;
//         }

       
//         if (result.length > 0) {
//             res.status(200).json(result);
//         } else {
//             res.status(404).json('No Purchases Found for User');
//         }
//     });
// });

// //Shreya:''
// app.post('/Shreya', (req, res) => {
//     const userId = req.body.id; 

//     const q = `SELECT u.id, u.username, SUM(pi.total_price) AS amount
//     FROM users u
//     JOIN purchesed_items pi ON u.id = pi.userId
//     GROUP BY u.id, u.username`; 

//     db.query(q, [userId], (err, result) => {
//         if (err) {
//             console.error(err);
//             res.status(500).json('Server Error');
//             return;
//         }

        
//         if (result.length > 0) {
//             res.status(200).json(result);
//         } else {
//             res.status(404).json('No Purchases Found for User');
//         }
//     });
// });


app.listen(8080, "192.168.30.75", () => {
    console.log("Hi server is running at: http://192.168.30.75:8080");
});
