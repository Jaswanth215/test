import mysql from 'mysql2';

const db = mysql2.createConnection({
    host: '192.168.30.75',
    user: 'user',
    password: 'pass',
    database: 'ecart'   
});
export default db;







// db.connect(err => {
//     if (err) throw err;
//     console.log("connected to the db");
// });